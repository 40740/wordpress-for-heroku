<?php if (!defined('ABSPATH')) {die;} // Cannot access directly.


//美化二次开发用户请添加自定义设置框架到下面
//美化二次开发用户请添加自定义设置框架到下面
//美化二次开发用户请添加自定义设置框架到下面
//美化二次开发用户请添加自定义设置框架到下面
//美化二次开发用户请添加自定义设置框架到下面
//美化二次开发用户请添加自定义设置框架到下面
//美化二次开发用户请添加自定义设置框架到下面



//
// Field: 自定义选项框架 美化二开专用 代码已经注释
//


// CSF::createSection($prefix, array(
//     'title'       => '自定义选项框架',
//     'icon'        => 'fa fa-shield',
//     'description' => '自定义选项框架',
//     'fields'      => array(

//         array(
//             'id'    => '_diy_ripro_opt1',
//             'type'  => 'text',
//             'title' => '自定义选项1',
//             'after' => '自定义选项111111',
//         ),
//         array(
//             'id'    => '_diy_ripro_opt2',
//             'type'  => 'text',
//             'title' => '自定义选项2',
//             'after' => '自定义选项22222',
//         ),

//     ),
// ));
// 
// 